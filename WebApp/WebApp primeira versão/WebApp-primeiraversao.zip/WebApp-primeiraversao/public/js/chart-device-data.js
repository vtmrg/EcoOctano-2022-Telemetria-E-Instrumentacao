/* eslint-disable max-classes-per-file */
/* eslint-disable no-restricted-globals */
/* eslint-disable no-undef */
$(document).ready(() => {
  // if deployed to a site supporting SSL, use wss://
  const protocol = document.location.protocol.startsWith('https') ? 'wss://' : 'ws://';
  const webSocket = new WebSocket(protocol + location.host);

  
  var listaDados = [{ "ID": "id", "Horario": "data e hora", "Velocidade": "velocidade", "Corrente": "corrente", "Tensão": "tensao", "Potência": "potencia", "Temperatura": "temperatura" }];
  var idCont = 1;

  class DeviceData {
    constructor(deviceId) {
      this.deviceId = deviceId;
      this.maxLen = 50;
      this.timeData= new Array(this.maxLen);
      this.temperaturaData = new Array(this.maxLen);
      this.correnteData = new Array(this.maxLen);
      this.tensaoData = new Array(this.maxLen);
      this.velocidadeData = new Array(this.maxLen);
      this.potenciaData = new Array(this.maxLen);
    }

    addData( time , temperatura, corrente, tensao, velocidade, potencia) {

    var data = new Date(time);
    var dataBRT = data.toLocaleString('pt-BR', {hour12: false}) +":"+data.getMilliseconds().toString();
    var dataAux=dataBRT.slice(0,2)+"-"+dataBRT.slice(3,5)+"-"+dataBRT.slice(6,10)+" "+dataBRT.slice(10,22);
    console.error(dataAux);
    this.timeData.push(dataBRT);
     
    this.temperaturaData.push(temperatura);
    this.correnteData.push(corrente);
    this.tensaoData.push(tensao);
    this.velocidadeData.push(velocidade);
    potencia = corrente * tensao;
    this.potenciaData.push(potencia);``

      criacao_dado(dataBRT,temperatura,corrente,tensao,velocidade,potencia);
      
      if (this.timeData.length > this.maxLen) {
        this.timeData.shift();
        this.temperaturaData.shift();
        this.velocidadeData.shift();
        this.correnteData.shift();
        this.tensaoData.shift();
        this.potenciaData.shift();
      }
    }
  }

  class TrackedDevices {
    constructor() {
      this.devices = [];
    }
    findDevice(deviceId) {
      for (let i = 0; i < this.devices.length; ++i) {
        if (this.devices[i].deviceId === deviceId) {
          return this.devices[i];
        }
      }
      return undefined;
    }

    getDevicesCount() {
      return this.devices.length;
    }
  }

  const trackedDevices = new TrackedDevices();

  const graficoTensaoDado = {
    datasets: [
      {
        // Verificar se todas as definições são necessárias
        fill: false,
        label: 'Tensao',
        yAxisID: 'Tensao',
        borderColor: 'rgba(248, 84, 1, 1)',
        pointBoarderColor: 'rgba(248, 84, 1, 1)',
        backgroundColor: 'rgba(248, 84, 1, 0.5)',
        pointHoverBackgroundColor: 'rgba(248, 84, 1, 1)',
        pointHoverBorderColor: 'rgba(248, 84, 1, 1)',
        spanGaps: true,
      },
      {
        fill: false,
        label: 'Corrente',
        yAxisID: 'Corrente',
        borderColor: 'rgba(2, 132, 197, 1)',
        pointBoarderColor: 'rgba(2, 132, 197, 1)',
        backgroundColor: 'rgba(2, 132, 197, 0.5)',
        pointHoverBackgroundColor: 'rgba(2, 132, 197, 1)',
        pointHoverBorderColor: 'rgba(2, 132, 197, 1)',
        spanGaps: true,
      }
    ]
  };

  const chartOptionsTensao = {
    scales: {
      yAxes: [{
        id: 'Tensao',
        type: 'linear',
        scaleLabel: {
          labelString: 'Tensão (V)',
          display: true, 
        },
        position: 'right',
      },
      {
        id: 'Corrente',
        type: 'linear',
        scaleLabel: {
          labelString: 'Corrente (A)',
          display: true,
        },
        position: 'left',
      }]
    }
  };

  const ctxTensao = document.getElementById('grfcTensaoCorrente').getContext('2d');
  const graficoTensao = new Chart(
    ctxTensao,
    {
      type: 'line',
      data: graficoTensaoDado,
      options: chartOptionsTensao,
    });

  const graficoVelocidadeDado = {
    datasets: [{
      fill: false,
      label: 'Velocidade',
      yAxisID: 'Velocidade',
      borderColor: 'rgba(172, 1, 30, 1)',
      pointBoarderColor: 'rgba(172, 1, 30, 1)',
      backgroundColor: 'rgba(172, 1, 30, 0.5)',
      pointHoverBackgroundColor: 'rgba(172, 1, 30, 1)',
      pointHoverBorderColor: 'rgba(172, 1, 30, 1)',
      spanGaps: true,
    },
    {
      fill: false,
      label: 'Potência',
      yAxisID: 'Potencia',
      borderColor: 'rgba(248, 208, 1, 1)',
      pointBoarderColor: 'rgba(248, 208, 1, 1))',
      backgroundColor: 'rgba(248, 208, 1, 0.5)',
      pointHoverBackgroundColor: 'rgba(248, 208, 1, 1)',
      pointHoverBorderColor: 'rgba(248, 208, 1, 1)',
      spanGaps: true,
    }]
  };

  const velocidadeOptions = {
    scales: {
      yAxes: [{
        id: 'Velocidade',
        type: 'linear',
        scaleLabel: {
          labelString: 'Velocidade (km/h)',
          display: true,
        },
        position: 'right',
      },
      {
        id: 'Potencia',
        type: 'linear',
        scaleLabel: {
          labelString: 'Potência (V)',
          display: true,
        },
        position: 'left',
      }
      ]
    }
  };

  const ctxVelocidade = document.getElementById('grfcVelocidadePotencia').getContext('2d');
  const graficoVelocidade = new Chart(
    ctxVelocidade,
    {
      type: 'line',
      data: graficoVelocidadeDado,
      options: velocidadeOptions,
    });

  let needsAutoSelect = true;

  function OnSelectionChange() {
    const device = trackedDevices.findDevice("myDeviceId);
    
    graficoTensaoDado.labels = device.timeData;
    graficoTensaoDado.datasets[0].data = device.tensaoData;
    graficoTensaoDado.datasets[1].data = device.correnteData;
    graficoTensao.update();

    graficoVelocidadeDado.labels = device.timeData;
    graficoVelocidadeDado.datasets[0].data = device.velocidadeData;
    graficoVelocidadeDado.datasets[1].data = device.potenciaData;
    graficoVelocidade.update();
  }

  function criacao_dado (horarioFuncao , temperaturaFuncao, velocidadeFuncao, correnteFuncao,tensaoFuncao, potenciaFuncao) {
      var dado = new Object();
      dado.id = idCont;
      idCont++;
      dado.horarioDado = horarioFuncao;
      dado.velocidadeDado = velocidadeFuncao;
      dado.correnteDado = correnteFuncao;
      dado.tensaoDado = tensaoFuncao;
      dado.potenciaDado = potenciaFuncao;
      dado.temperaturaDado = temperaturaFuncao ;

      atualizarValores(temperaturaFuncao, correnteFuncao, potenciaFuncao, tensaoFuncao, velocidadeFuncao);
      opacidade(potenciaFuncao);

      listaDados.push(dado);


  }

  webSocket.onmessage = function onMessage(message) {
    try {
      const messageData = JSON.parse(message.data);
      console.log(messageData);

     if (!messageData.MessageDate || (!messageData.IotData.temperatura && !messageData.IotData.corrente && !messageData.IotData.tensao && !messageData.IotData.velocidade && !messageData.IotData.potencia)) {
        return;
      }

      const existingDeviceData = trackedDevices.findDevice(messageData.DeviceId);

      if (existingDeviceData) {
        existingDeviceData.addData(messageData.MessageDate, messageData.IotData.temperatura, messageData.IotData.corrente, messageData.IotData.tensao, messageData.IotData.velocidade, messageData.IotData.potencia);
      } else {
        const newDeviceData = new DeviceData(messageData.DeviceId);
        trackedDevices.devices.push(newDeviceData);
        newDeviceData.addData(messageData.MessageDate, messageData.IotData.temperatura, messageData.IotData.corrente, messageData.IotData.tensao, messageData.IotData.velocidade, messageData.IotData.potencia);

        if (needsAutoSelect) {
          needsAutoSelect = false;
          OnSelectionChange();
        }
      }
      graficoTensao.update();
      graficoVelocidade.update();
    } catch (err) {
      console.error(err);
    }
  };



  document.getElementById("btnSalvar").addEventListener("click", salvarDados);



  function salvarDados() {
    let csv
    for (let row = 0; row < listaDados.length; row++) {
      let keysAmount = Object.keys(listaDados[row]).length
      let keysCounter = 0
      if (row === 0) {
        for (let key in listaDados[row]) {
          csv += key + (keysCounter + 1 < keysAmount ? ',' : '\r\n')
          keysCounter++
        }
      } else {
        for (let key in listaDados[row]) {
          csv += listaDados[row][key] + (keysCounter + 1 < keysAmount ? ',' : '\r\n')
          keysCounter++
        }
      }
      keysCounter = 0
    }

    let link = document.createElement('a')
    link.id = 'download-csv'
    link.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(csv));
    link.setAttribute('download', 'dadosTelemetria.csv');
    document.body.appendChild(link)
    document.querySelector('#download-csv').click()
  } 

  function atualizarValores(temperatura, corrente, potencia, tensao, velocidade) {
    document.getElementById("valorTemperatura").innerHTML = Math.round(temperatura).toString()+" °C";
    document.getElementById("valorCorrente").innerHTML = corrente.toFixed(2).toString()+" A";
    document.getElementById("valorTensao").innerHTML = tensao.toFixed(2).toString()+" V";
    //document.getElementById("valorVelocidade").innerHTML = Math.round(velocidade).toString();
    document.getElementById("valorVelocidade").innerHTML = (velocidade).toString();
    document.getElementById("valorPotencia").innerHTML = potencia.toFixed(2).toString()+" W";
  }

  function opacidade(potencia){
    if (potencia <= 60){
      document.getElementById("potMax").style.opacity = "1";
      document.getElementById("pot80").style.opacity = "0.25";
      document.getElementById("pot60").style.opacity = "0.25";
      document.getElementById("pot40").style.opacity = "0.25";
      document.getElementById("pot20").style.opacity = "0.25";
      document.getElementById("potMin").style.opacity = "0.25";
    }else if(potencia > 60 && potencia <= 120){
        document.getElementById("potMax").style.opacity = "0.25";
        document.getElementById("pot80").style.opacity = "1";
        document.getElementById("pot60").style.opacity = "0.25";
        document.getElementById("pot40").style.opacity = "0.25";
        document.getElementById("pot20").style.opacity = "0.25";
        document.getElementById("potMin").style.opacity = "0.25";
    }else if(potencia > 120 && potencia <= 180){
        document.getElementById("potMax").style.opacity = "0.25";
        document.getElementById("pot80").style.opacity = "0.25";
        document.getElementById("pot60").style.opacity = "1";
        document.getElementById("pot40").style.opacity = "0.25";
        document.getElementById("pot20").style.opacity = "0.25";
        document.getElementById("potMin").style.opacity = "0.25";
    }else if(potencia > 180 && potencia <= 240){
        document.getElementById("potMax").style.opacity = "0.25";
        document.getElementById("pot80").style.opacity = "0.25";
        document.getElementById("pot60").style.opacity = "0.25";
        document.getElementById("pot40").style.opacity = "1";
        document.getElementById("pot20").style.opacity = "0.25";
        document.getElementById("potMin").style.opacity = "0.25";
    }else if(potencia > 240 && potencia <= 300){
        document.getElementById("potMax").style.opacity = "0.25";
        document.getElementById("pot80").style.opacity = "0.25";
        document.getElementById("pot60").style.opacity = "0.25";
        document.getElementById("pot40").style.opacity = "0.25";
        document.getElementById("pot20").style.opacity = "1";
        document.getElementById("potMin").style.opacity = "0.25";
    }else if(potencia > 300){
        document.getElementById("potMax").style.opacity = "0.25";
        document.getElementById("pot80").style.opacity = "0.25";
        document.getElementById("pot60").style.opacity = "0.25";
        document.getElementById("pot20").style.opacity = "0.25";
        document.getElementById("pot20").style.opacity = "0.25";
        document.getElementById("potMin").style.opacity = "1";
    }
  }
});
